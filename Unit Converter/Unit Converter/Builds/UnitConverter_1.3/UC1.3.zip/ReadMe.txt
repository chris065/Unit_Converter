To install the application, click on the "setup.exe" and then click "install" when the message box appears.

Then the application should launch, once it has finished installing. 

if there are any bugs and or issues, visit this page: https://github.com/chris065/Unit_Converter/issues and report the issue there.

Enjoy.

-----> This is version 1.3, so this is not the finished product, and not all of the features are present as these will come in
feature updates. Just to let you know.

-----> UPDATE NOTES:
------->When you are selecting the Unit to convert from (i.e. KM, M or CM) you can now just press, for example, "a" rather than having to type capital A.
------->Now inlcudes Temp Conversion.
------->Now includes Mass (From Metric to imperial Units) conversion. 
------->Now includes Astronomy Conversion (Light years to meters, Parsecs to meters etc.)
------->Now includes Volume Conversion (Metric to imperial units)